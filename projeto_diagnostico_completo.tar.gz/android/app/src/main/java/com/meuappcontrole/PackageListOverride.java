package com.meuappcontrole;

public class PackageListOverride {
    // placeholder to avoid missing-class compile issues in limited setups
}
