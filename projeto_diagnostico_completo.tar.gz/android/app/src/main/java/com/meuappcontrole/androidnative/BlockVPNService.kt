package com.meuappcontrole.androidnative

import android.net.VpnService

class BlockVPNService : VpnService() {

}
